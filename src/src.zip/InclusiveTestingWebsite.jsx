import React from 'react';

const InclusiveTestingWebsite = () => {
  return (
    <div className="website-container">
      {/* Header */}
      <header>
        <div className="container">
          <div className="logo">
            <img src="logo.png" alt="Narxcent logo" className="logo-img" />
            <span>Prayog Sarthi</span>
          </div>
          <nav>
            <a href="#">Home</a>
            <a href="#">Ngo's</a>
            <a href="#">Blog</a>
            <a href="AboutUs.jsx">About Us</a>
          </nav>
          <button className="btn">Register Now</button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="hero">
        <div className="container">
          <div className="hero-content">
            <div className="hero-title-box">
              <h1 className="hero-title">
                <b>Empowering</b> <br />
                Innovation Through <br />
                <span>Inclusive Testing</span>
              </h1>
            </div>
            <p className="hero-subtitle">
              Making digital products accessible for everyone
            </p>
            <button className="btn btn-lg">
              Get Started
            </button>
          </div>
          <div className="hero-image">
            <img 
              src="/hero-image.png" 
              alt="Person testing software on laptop" 
            />
          </div>
        </div>
      </section>

      {/* Trusted By Section */}
      <section className="trusted">
        <div className="container">
          <h2 className="trusted-title">Trusted by NGOs</h2>
          <div className="logo-grid">
            <img src="/client-logo-1.png" alt="Partner logo" />
            <img src="/client-logo-2.png" alt="Partner logo" />
            <img src="/client-logo-3.png" alt="Partner logo" />
            <img src="/client-logo-4.png" alt="Partner logo" />
            <img src="/client-logo-5.png" alt="Partner logo" />
            <img src="/client-logo-6.png" alt="Partner logo" />
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="services">
        <div className="container">
          <h2 className="services-title">
          Bridging Companies with Specially-Abled <br />
          Testers for Smarter Products
          </h2>
          <div className="services-grid">
            <div className="service-card">
              <img src="/research-icon.png" alt="Research icon" />
              <h3 className="service-title">Research & Development</h3>
              <p className="service-desc">
                Innovative testing solutions for modern products
              </p>
            </div>
            <div className="service-card">
              <img src="/consulting-icon.png" alt="Consulting icon" />
              <h3 className="service-title">Consulting & Services</h3>
              <p className="service-desc">
                Expert guidance for accessibility compliance
              </p>
            </div>
            <div className="service-card">
              <img src="/accessibility-icon.png" alt="Accessibility icon" />
              <h3 className="service-title">Accessibility Advocates</h3>
              <p className="service-desc">
                Champions for inclusive digital experiences
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Section 1 */}
      <section className="feature feature-right">
        <div className="container">
          <div className="feature-content">
            <h2 className="feature-title">
              How User Testing Drives Inclusive Innovation
            </h2>
            <p className="feature-desc">
            Inclusive testing is the key to designing products that work for everyone. At Prayog Sarthi, we connect specially-abled individuals with companies to ensure products are accessible, practical, and impactful.
            </p>
            <button className="btn">
              Learn More
            </button>
          </div>
          <div className="feature-image">
            <img 
              src="/feature-image-1.png" 
              alt="User testing illustration" 
            />
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="stats">
        <div className="container">
          <div className="stats-brand">
            <h2 className="stats-brand-name">
              <span>@DesignInclusive</span>
            </h2>
            <p className="stats-brand-tagline">
              Building a Better Tomorrow
            </p>
          </div>
          <div className="stats-numbers">
            <div className="stat">
              <span className="stat-number">500+</span>
              <p className="stat-label">Products Tested</p>
            </div>
            <div className="stat">
              <span className="stat-number">98+</span>
              <p className="stat-label">Countries</p>
            </div>
            <div className="stat">
              <span className="stat-number">10</span>
              <p className="stat-label">Years Experience</p>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Section 2 */}
      <section className="feature feature-left">
        <div className="container">
          <div className="feature-content">
            <h2 className="feature-title">
              How Inclusive Testing Enhances Product Development
            </h2>
            <p className="feature-desc">
            Building truly accessible technology requires insights from those who experience accessibility challenges firsthand. At Prayog Sarthi, we bridge the gap between specially-abled individuals and companies, enabling businesses to refine their products with real-world user feedback. Our platform empowers testers to share their experiences, helping developers identify usability barriers, enhance accessibility features, and create products that cater to diverse needs. We ensure inclusivity is integrated at every stage of product development, making technology more intuitive, adaptive, and user-friendly for everyone.
            </p>
            <button className="btn">
              Learn More
            </button>
          </div>
          <div className="feature-image">
            <img 
              src="/feature2.png" 
              alt="Product development illustration" 
            />
          </div>
        </div>
      </section>

      

      {/* Cards Section */}
      <section className="cards">
        <div className="container">
          <h2 className="cards-title">
            Accessibility is the Future of Innovation
          </h2>
          <div className="cards-grid">
            <div className="card">
              <img src="/card1.png" alt="Children using digital devices" className="card-image" />
              <div className="card-content">
                <h3 className="card-title">Inclusive Education</h3>
                <p className="card-desc">Making learning accessible for all children</p>
              </div>
            </div>
            <div className="card">
              <img src="/card2.png" alt="Elderly using technology" className="card-image" />
              <div className="card-content">
                <h3 className="card-title">Senior-Friendly Design</h3>
                <p className="card-desc">Bridging the digital divide for older adults</p>
              </div>
            </div>
            <div className="card">
              <img src="/card3.png" alt="Accessible testing" className="card-image" />
              <div className="card-content">
                <h3 className="card-title">Comprehensive Testing</h3>
                <p className="card-desc">Ensuring products work for everyone</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="cta">
        <div className="container">
          <h2 className="cta-title">
            <span>Join Us</span> in Building a More <br />
            Accessible Future!
          </h2>
          <button className="btn btn-lg">
            Get Started Today
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer>
        <div className="container">
          <div className="footer-grid">
            <div>
              <div className="footer-logo">
                <img src="/logo-white.png" alt="Narxcent logo" />
                <span>Narxcent</span>
              </div>
              <p className="footer-desc">
                Making the digital world accessible for everyone
              </p>
            </div>
            <div>
              <h3 className="footer-heading">Company</h3>
              <ul className="footer-links">
                <li><a href="#">About Us</a></li>
                <li><a href="#">Careers</a></li>
                <li><a href="#">Blog</a></li>
              </ul>
            </div>
            <div>
              <h3 className="footer-heading">Support</h3>
              <ul className="footer-links">
                <li><a href="#">Help Center</a></li>
                <li><a href="#">Contact Us</a></li>
                <li><a href="#">Resources</a></li>
              </ul>
            </div>
            <div>
              <h3 className="footer-heading">Stay in the loop</h3>
              <p className="footer-newsletter-text">
                Subscribe to our newsletter for the latest updates
              </p>
              <div className="footer-form">
                <input 
                  type="email" 
                  placeholder="Your email" 
                  className="footer-input"
                />
                <button className="footer-button">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
          <div className="footer-bottom">
            <p className="footer-copyright">
              © 2025 Narxcent. All rights reserved.
            </p>
            <div className="footer-social">
              <a href="#" className="footer-social-link">
                <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path fillRule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clipRule="evenodd" />
                </svg>
              </a>
              <a href="#" className="footer-social-link">
                <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                </svg>
              </a>
              <a href="#" className="footer-social-link">
                <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path fillRule="evenodd" d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" clipRule="evenodd" />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default InclusiveTestingWebsite;