import React from 'react';
import './App.css';
import InclusiveTestingWebsite from './InclusiveTestingWebsite';
import AboutUs from './AboutUs';

function App() {
  return (
    <div className="App">
      <InclusiveTestingWebsite />
      <AboutUs/>
    </div>
  );
}

export default App;